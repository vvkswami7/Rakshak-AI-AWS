# Sentinel-X 🚗🚨

**Real-Time Edge AI Accident Detection & Response System** - IBM Hackathon Edition

Sentinel-X is an intelligent traffic accident detection and automated response system that combines **YOLOv8 Edge AI** with **IBM watsonx Orchestrate** and **real-time telemetry** to detect accidents, assess severity, and trigger emergency workflows automatically.

---

## 🎯 Project Overview

Sentinel-X addresses critical gaps in road safety by:

1. **Real-Time Accident Detection** using YOLOv8 on edge devices
2. **Intelligent Severity Classification** (MINOR/MODERATE/SEVERE)
3. **Vehicle Type Classification** (cars, trucks, motorcycles, buses, bicycles, pedestrians)
4. **Automated IBM Agent Trigger** for emergency dispatch coordination
5. **Evidence Archiving** with timestamped crash footage
6. **Multi-Channel Alerting** via Telegram with location data
7. **Incident Heatmap Tracking** for traffic analytics
8. **Queue Length & Wait Time Estimation** for traffic management

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│  FRONTEND (React Dashboard)                             │
│  - Live accident alerts                                 │
│  - WebSocket connection                                 │
│  - Evidence history viewer                              │
│  - Severity & vehicle metrics                           │
│  - Incident heatmap                                     │
└────────────────┬────────────────────────────────────────┘
                 │
         WebSocket /ws
                 │
┌────────────────▼────────────────────────────────────────┐
│  BACKEND (FastAPI + YOLO)                               │
│  - Real-time video stream processing                    │
│  - YOLOv8 inference                                     │
│  - Accident detection logic                             │
│  - IBM watsonx integration                              │
│  - Evidence capture & storage                           │
└────────────────┬────────────────────────────────────────┘
                 │
        ┌────────┴──────────┬──────────────┐
        │                   │              │
   Mobile Camera      IBM watsonx      Telegram Bot
   (IP Webcam)        (Orchestrate)    (Alerts)
```

---

## ✨ Key Features

### 1. **Accident Severity Classification** 🚨
- **SEVERE**: 3+ vehicles OR high-confidence crash + multiple vehicles
- **MODERATE**: 2 vehicles + crash detection
- **MINOR**: 1 vehicle OR low confidence

### 2. **Vehicle Type Recognition** 🚗
- Cars, Trucks, Motorcycles, Buses, Bicycles, Pedestrians
- Classifies each detected object automatically

### 3. **IBM watsonx Integration** 🤖
- Exchanges API Key for Bearer Token
- Sends detailed accident reports to IBM Agent
- Triggers automated emergency workflows
- Receives confirmation from Watson Assistant

### 4. **Evidence Archiving** 📸
- Automatically captures accident frames
- Saves with timestamp and severity level
- Stores in `evidence_archive/crashes/`
- Format: `evidence_YYYYMMDD_HHMMSS_SEVERITY_crash.jpg`

### 5. **Telegram Notifications** 📱
- Sends crash photo with severity indicator
- Includes location coordinates (lat/lon)
- Real-time alerts to emergency contacts

### 6. **Incident Heatmap** 🗺️
- Tracks all detected incidents with location
- Color-coded by severity level
- Useful for traffic pattern analysis

### 7. **Queue Management** 📊
- Estimates queue length in meters
- Calculates wait time based on vehicle count
- Helps with traffic signal optimization

---

## 📋 Tech Stack

| Component | Technology | Version |
|-----------|------------|---------|
| **Backend** | FastAPI | 0.104.1 |
| **Server** | Uvicorn | 0.24.0 |
| **AI/ML** | YOLO (Ultralytics) | 8.0.207 |
| **Computer Vision** | OpenCV | 4.8.1.78 |
| **Frontend** | React | Latest |
| **Maps** | Leaflet | Latest |
| **Config** | Python-dotenv | 1.0.0 |
| **HTTP Client** | Requests | 2.31.0 |

---

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- Node.js 14+
- Mobile device with IP Webcam app (Android)
- IBM Cloud account with API Key
- Telegram Bot Token

### 1️⃣ Backend Setup (Python)

```bash
# Navigate to project root
cd /home/vivek/sentinel-x

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or: venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt

# Create .env file with your credentials
cp .env.example .env

# Edit .env with:
# - CAMERA_URL=http://YOUR_MOBILE_IP:8080/video
# - IBM_API_KEY=your_ibm_cloud_api_key

# Run the backend server
python main.py
```

**Backend runs at**: `http://localhost:8000`  
**WebSocket endpoint**: `ws://localhost:8000/ws`

### 2️⃣ Frontend Setup (React)

```bash
# In a new terminal, navigate to dashboard folder
cd sentinel-dashboard

# Install dependencies
npm install

# Create .env file (optional - defaults work for localhost)
cp .env.example .env

# Start development server
npm start
```

**Frontend opens at**: `http://localhost:3000`

---

## 📁 Project Structure

```
sentinel-x/
├── main.py                          # FastAPI backend with YOLO integration
├── requirements.txt                 # Python dependencies
├── apikey.json                      # IBM credentials (gitignored)
├── yolov8n.pt                       # YOLOv8 nano model weights
├── README.md                        # This file
├── SETUP.md                         # Detailed setup guide
│
├── evidence_archive/
│   └── crashes/                     # Stored crash evidence frames
│
├── weights/
│   └── models/
│       ├── newbest.pt              # Custom accident detection model
│       ├── backup_best.pt          # Backup model
│       ├── ambulance.pt            # Ambulance detection
│       ├── damage.pt               # Damage detection
│       └── vehicle_counting.pt     # Vehicle counting model
│
└── sentinel-dashboard/              # React frontend
    ├── package.json
    ├── public/
    │   ├── index.html
    │   ├── manifest.json
    │   └── robots.txt
    └── src/
        ├── App.js                   # Main dashboard component
        ├── App.css                  # Styling
        ├── index.js                 # React entry point
        └── ...other components
```

---

## ⚙️ Environment Variables

### Backend (.env in root directory)

```env
# Camera Configuration
CAMERA_URL=http://10.167.144.147:8080/video

# IBM Cloud Credentials
IBM_API_KEY=your_ibm_cloud_api_key
IBM_REGION=eu-de

# Telegram Bot
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
TELEGRAM_CHAT_ID=your_chat_id
```

### Frontend (.env in sentinel-dashboard/)

```env
REACT_APP_BACKEND_URL=ws://localhost:8000/ws
REACT_APP_CAMERA_URL=http://10.167.144.147:8080/video
```

---

## 🔑 API Endpoints

### WebSocket: `/ws`
**Real-time accident detection stream**

**Message Format (Frontend receives):**
```json
{
  "detections": [
    {
      "label": "car",
      "conf": 0.95,
      "bbox": [100, 150, 300, 400],
      "type": "car"
    }
  ],
  "accident_alert": true,
  "ibm_agent_status": "active",
  "severity": "SEVERE",
  "vehicle_count_by_type": {
    "car": 2,
    "truck": 1,
    "motorcycle": 0,
    "bus": 0,
    "bicycle": 0,
    "person": 1,
    "other": 0
  },
  "total_vehicles": 3,
  "heatmap_hotspots": [
    {
      "location": [15.4589, 75.0078],
      "severity": "SEVERE",
      "time": "2026-02-01T14:30:45.123456"
    }
  ],
  "queue_info": {
    "estimated_queue_length_m": 13.5,
    "estimated_wait_time_s": 6,
    "vehicle_count": 3
  }
}
```

---

## 🤖 IBM watsonx Integration

### Authentication Flow
1. Exchange API Key for Bearer Token
2. Send accident message to IBM Agent
3. Include severity, vehicle count, location, confidence

### Trigger Requirements
- Confidence threshold: **40%** for critical keywords (crash, accident, etc.)
- Confidence threshold: **70%** for supporting keywords (vehicle, person)
- Cooldown period: **60 seconds** between triggers
- Evidence capture cooldown: **15 seconds** between saves

### Example Trigger Message
```
REPORT ACCIDENT: I have detected a vehicle crash. 
Severity: SEVERE. 
Vehicles Involved: 3. 
Confidence: 95%. 
Location: Pune_Main_Road. 
Time: 2026-02-01 14:30:45. 
Dispatching emergency services required.
```

---

## 📸 Evidence Management

### Automatic Capture
- Triggered on accident detection
- Respects 15-second cooldown
- Captures from current video frame
- Includes severity level in filename

### Storage
- Location: `evidence_archive/crashes/`
- Format: `evidence_YYYYMMDD_HHMMSS_SEVERITY_crash.jpg`
- Example: `evidence_20260201_143045_SEVERE_crash.jpg`

### Telegram Integration
- Photo with caption (severity emoji)
- Location with GPS coordinates
- Custom caption with incident details

---

## 🐛 Troubleshooting

### Issue: Camera stream not working
**Solution:**
- Verify IP Webcam app is running on mobile device
- Check IP address and port in `CAMERA_URL`
- Ensure both devices are on the same network
- Test camera URL in browser

### Issue: IBM Agent not triggering
**Solution:**
- Verify `IBM_API_KEY` is correct in `.env`
- Check internet connection
- Review console logs for auth errors
- Verify integration ID is correct

### Issue: WebSocket connection failed
**Solution:**
- Ensure backend is running: `python main.py`
- Check FastAPI server is listening on port 8000
- Verify firewall allows connections

### Issue: Telegram alerts not sending
**Solution:**
- Verify `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`
- Check internet connectivity
- Review Telegram API response in console logs
- Ensure bot has permission to send media

### Issue: Low detection accuracy
**Solution:**
- Check lighting conditions at camera location
- Adjust confidence thresholds in `main.py`
- Use custom model: `weights/models/newbest.pt`
- Ensure camera resolution is adequate (720p+ recommended)

---

## 📊 Model Details

### Primary Model: `weights/models/newbest.pt`
- Custom YOLO model fine-tuned for accident detection
- Detects: crashes, damage, vehicles, people
- Inference confidence: 40%+ for critical classes

### Fallback Model: `yolov8n.pt`
- Standard YOLOv8 Nano
- General object detection
- Confidence threshold: 40%+

### Supported Classes
- accident, crash, car_crash, damage, wreck, severe, collision
- car, truck, motorcycle, bus, bicycle, person
- ambulance, traffic_signal, road_sign

---

## 🎮 Dashboard Features

### Real-Time Display
- **Connection Status**: Green (connected) / Red (disconnected)
- **Accident Alert**: Sticky red banner on detection
- **IBM Status**: Shows when Watson Agent is active
- **Live Detections**: List of detected objects with confidence

### Metrics Panel
- Severity Level (MINOR/MODERATE/SEVERE)
- Vehicle count by type
- Total vehicles involved
- Estimated queue length
- Estimated wait time

### Evidence History
- Timestamped list of detected incidents
- Confidence levels
- Severity classification
- Evidence status (active/archived)

### Incident Heatmap
- Map showing all incident locations
- Color-coded markers by severity
- Hover for incident details
- Zoom and pan support

---

## 📝 Configuration Tips

### Optimizing Detection
1. **Adjust confidence thresholds** in `main.py`:
   - Lower for more sensitivity (more false positives)
   - Higher for precision (might miss incidents)

2. **Camera placement**:
   - Mount at intersection center
   - Ensure clear view of vehicles
   - Adequate lighting (day) or IR support (night)

3. **Model selection**:
   - Use `newbest.pt` for accident-specific detection
   - Use `yolov8n.pt` as fallback

### IBM Agent Configuration
- Set cooldown period based on alert sensitivity
- Adjust message content for dispatcher system
- Configure service instance IDs in `.env`

---

## 🔒 Security Notes

⚠️ **Important:**
- Do NOT commit `.env` file or `apikey.json` to version control
- Use environment variables for all credentials
- Rotate IBM API keys regularly
- Restrict camera URL access to trusted networks
- Use HTTPS/WSS in production

---

## 📚 Additional Resources

- [YOLOv8 Documentation](https://docs.ultralytics.com/)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [IBM watsonx Orchestrate API](https://cloud.ibm.com/docs)
- [React + Leaflet Maps](https://react-leaflet.js.org/)

---

## 🤝 Contributing

Contributions welcome! Areas for improvement:
- [ ] Multi-camera support
- [ ] Machine learning retraining pipeline
- [ ] Advanced heatmap clustering
- [ ] Historical analytics dashboard
- [ ] Mobile app version
- [ ] Edge deployment (Jetson, Raspberry Pi)

---

## 📄 License

This project is part of the IBM Hackathon initiative.

---

## 👥 Support

For issues, questions, or suggestions:
- Check [SETUP.md](SETUP.md) for detailed setup instructions
- Review console logs for error messages
- Verify all environment variables are set correctly

**Last Updated:** February 1, 2026
